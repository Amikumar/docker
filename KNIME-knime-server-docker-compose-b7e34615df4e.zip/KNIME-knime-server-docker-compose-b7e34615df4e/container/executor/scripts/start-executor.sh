#!/usr/bin/env bash

echo "Entering RabbitMQ startup grace period (120 seconds)."
sleep 120

echo "Initializing KNIME Executor."
bash knime-executor/start-executor.sh

while true
do
    sleep 1
done
